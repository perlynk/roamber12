smalltalk.addPackage('Helios-Exceptions');
smalltalk.addClass('HLError', smalltalk.Error, [], 'Helios-Exceptions');


smalltalk.addClass('HLChangeForbidden', smalltalk.HLError, [], 'Helios-Exceptions');


